export const betTypes = {
    Normal: "Normal",
    SNR: "SNR",
    SR: "SR"
}