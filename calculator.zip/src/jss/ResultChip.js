export default {
    left: '50%',
    color: '#00FF00',
    borderColor: '#fff',
    fontWeight: 'bold'
};