export default {
    border: "3px solid #c58800"
}